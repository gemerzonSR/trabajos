<?php include("template/cabecera.php"); ?>


<div class="col-md-6">
            <br/>
                <div class="jumbotron">
                    
					<h3 class="display-4">Nosotros</h3>
                    <p class="lead">Somos una empresa responsable que se dedica a la venta de libros  </p>
                    
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d309143.7729001129!2d-89.72119974927166!3d21.003631842157876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjHCsDAwJzM4LjEiTiA4OcKwMzQnNDUuMiJX!5e0!3m2!1ses-419!2smx!4v1622861855244!5m2!1ses-419!2smx" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
</div>



 <div class="col-md-6">
            <br/>
                <div class="jumbotron">
                    
					<h3 class="display-4">Misión</h3>
                    <p class="lead">Bienvenidos a nuestro sitio web de libros </p>
                    
                    
                </div>
				<div class="jumbotron">
                    
					<h3 class="display-4">Contáctanos</h3>
                    <p class="lead">Contáctanos: <a href="#">Facebook</a> | <a href="#">Twitter</a> </p>
                    
                    
                </div>
</div>


<?php include("template/pie.php"); ?>